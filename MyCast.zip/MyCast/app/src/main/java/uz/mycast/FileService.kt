package uz.mycast

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.IBinder
import java.io.FileInputStream
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

/** Telefondagi video faylni HTTP orqali (Range qo'llab-quvvatlanadi) planshetga beradi. */
class FileService : Service() {

    private var server: ServerSocket? = null
    @Volatile private var running = false
    @Volatile private var uri: Uri? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        uri = intent?.data ?: return START_NOT_STICKY
        startAsForeground()
        startServer()
        return START_NOT_STICKY
    }

    private fun startServer() {
        if (running) return
        running = true
        thread(name = "file-http") {
            try {
                server = ServerSocket(PORT)
                while (running) {
                    val s = server!!.accept()
                    thread { handle(s) }
                }
            } catch (_: Exception) { }
        }
    }

    private fun handle(s: Socket) {
        try {
            s.use { sock ->
                val reader = sock.getInputStream().bufferedReader()
                val first = reader.readLine() ?: return
                var rangeHdr: String? = null
                while (true) {
                    val l = reader.readLine() ?: break
                    if (l.isEmpty()) break
                    if (l.startsWith("Range:", true)) rangeHdr = l.substring(6).trim()
                }
                val u = uri ?: return
                val pfd = contentResolver.openFileDescriptor(u, "r") ?: return
                pfd.use { fd ->
                    val size = fd.statSize
                    val mime = contentResolver.getType(u) ?: "video/mp4"
                    val range = rangeHdr
                    var start = 0L
                    var end = size - 1
                    if (range != null && range.startsWith("bytes=")) {
                        val p = range.removePrefix("bytes=").split("-")
                        if (p[0].isNotEmpty()) {
                            start = p[0].toLong()
                            if (p.size > 1 && p[1].isNotEmpty()) end = p[1].toLong().coerceAtMost(size - 1)
                        } else if (p.size > 1 && p[1].isNotEmpty()) {
                            start = (size - p[1].toLong()).coerceAtLeast(0)
                        }
                    }
                    val out = sock.getOutputStream()
                    if (start > end || start >= size) {
                        out.write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Range: bytes */$size\r\nConnection: close\r\n\r\n".toByteArray())
                        out.flush()
                        return
                    }
                    val len = end - start + 1
                    val status = if (range != null) "206 Partial Content" else "200 OK"
                    val sb = StringBuilder()
                    sb.append("HTTP/1.1 $status\r\n")
                    sb.append("Content-Type: $mime\r\n")
                    sb.append("Accept-Ranges: bytes\r\n")
                    sb.append("Content-Length: $len\r\n")
                    if (range != null) sb.append("Content-Range: bytes $start-$end/$size\r\n")
                    sb.append("Connection: close\r\n\r\n")
                    out.write(sb.toString().toByteArray())
                    if (first.startsWith("HEAD")) { out.flush(); return }

                    val ch = FileInputStream(fd.fileDescriptor).channel
                    ch.position(start)
                    val input = java.nio.channels.Channels.newInputStream(ch)
                    val buf = ByteArray(64 * 1024)
                    var left = len
                    while (left > 0 && running) {
                        val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                        if (n < 0) break
                        out.write(buf, 0, n)
                        left -= n
                    }
                    out.flush()
                }
            }
        } catch (_: Exception) { }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("file", "MyCast kino", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "file")
            .setContentTitle("MyCast")
            .setContentText("Kino planshetga uzatilmoqda")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(2, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(2, n)
        }
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) { }
        super.onDestroy()
    }

    companion object {
        const val PORT = 8081
        const val ACTION_STOP = "uz.mycast.FILE_STOP"
    }
}
