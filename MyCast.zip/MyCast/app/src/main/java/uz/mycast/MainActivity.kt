package uz.mycast

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : Activity() {

    private lateinit var info: TextView
    private lateinit var urlInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val pad = (24 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        root.addView(TextView(this).apply { text = "MyCast"; textSize = 28f })

        // ---------- TELEFON ----------
        root.addView(TextView(this).apply { text = "\nTELEFON (yuboruvchi)"; textSize = 16f })
        val movieBtn = Button(this).apply { text = "Kino yuborish (ovoz bilan)" }
        val screenBtn = Button(this).apply { text = "Ekranni yuborish (ovozsiz)" }
        val stopBtn = Button(this).apply { text = "Hammasini to'xtatish" }
        info = TextView(this).apply { textSize = 15f }
        root.addView(movieBtn)
        root.addView(screenBtn)
        root.addView(stopBtn)
        root.addView(info)

        // ---------- PLANSHET ----------
        root.addView(TextView(this).apply { text = "\nPLANSHET (qabul qiluvchi)"; textSize = 16f })
        urlInput = EditText(this).apply {
            hint = "Telefon IP, masalan 192.168.1.25"
            inputType = InputType.TYPE_TEXT_VARIATION_URI
            setText(getSharedPreferences("p", MODE_PRIVATE).getString("url", ""))
        }
        val watchBtn = Button(this).apply { text = "Kinoni ko'rish" }
        val mirrorBtn = Button(this).apply { text = "Ekranni ko'rish" }
        root.addView(urlInput)
        root.addView(watchBtn)
        root.addView(mirrorBtn)

        setContentView(ScrollView(this).apply { addView(root) })

        movieBtn.setOnClickListener {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "video/*"
            }
            @Suppress("DEPRECATION")
            startActivityForResult(i, REQ_VIDEO)
        }
        screenBtn.setOnClickListener {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            @Suppress("DEPRECATION")
            startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
        }
        stopBtn.setOnClickListener {
            startService(Intent(this, CastService::class.java).setAction(CastService.ACTION_STOP))
            startService(Intent(this, FileService::class.java).setAction(FileService.ACTION_STOP))
            info.text = "To'xtatildi."
        }
        watchBtn.setOnClickListener {
            val host = hostFromInput() ?: return@setOnClickListener
            startActivity(Intent(this, PlayerActivity::class.java)
                .putExtra("url", "http://$host:${FileService.PORT}/video"))
        }
        mirrorBtn.setOnClickListener {
            val host = hostFromInput() ?: return@setOnClickListener
            startActivity(Intent(this, ReceiverActivity::class.java)
                .putExtra("url", "http://$host:${CastService.PORT}"))
        }

        handleShare(intent)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    /** Telegram va boshqa ilovalardan "Ulashish -> MyCast" orqali kelgan videoni qabul qiladi. */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        if (i.type?.startsWith("video/") != true) return
        @Suppress("DEPRECATION")
        val uri = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM) ?: return
        startFile(uri)
    }

    private fun startFile(uri: Uri) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        val svc = Intent(this, FileService::class.java).apply {
            data = uri
            clipData = android.content.ClipData.newRawUri("", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startForegroundService(svc)
        info.text = addressText("Kino tayyor. Planshetda IP kiriting va \"Kinoni ko'rish\" ni bosing:")
    }

    /** Kiritilgan matndan faqat IP/host qismini oladi (http:// va :port bo'lsa ham). */
    private fun hostFromInput(): String? {
        var t = urlInput.text.toString().trim()
        if (t.isEmpty()) return null
        if (!t.contains("://")) t = "http://$t"
        val host = Uri.parse(t).host ?: return null
        getSharedPreferences("p", MODE_PRIVATE).edit().putString("url", host).apply()
        return host
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return

        if (requestCode == REQ_CAPTURE) {
            val i = Intent(this, CastService::class.java)
                .setAction(CastService.ACTION_START)
                .putExtra("code", resultCode)
                .putExtra("data", data)
            startForegroundService(i)
            info.text = addressText("Planshetda IP kiriting va \"Ekranni ko'rish\" ni bosing:")
        }

        if (requestCode == REQ_VIDEO) {
            val uri = data.data ?: return
            startFile(uri)
        }
    }

    private fun addressText(head: String): String {
        val ips = localIps()
        return if (ips.isEmpty()) "Wi-Fi yoki hotspotga ulanmagansiz."
        else head + "\n" + ips.joinToString("\n")
    }

    private fun localIps(): List<String> = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .filter { it.isUp && !it.isLoopback }
            .flatMap { it.inetAddresses.toList() }
            .filterIsInstance<Inet4Address>()
            .mapNotNull { it.hostAddress }
    } catch (e: Exception) { emptyList() }

    companion object {
        private const val REQ_CAPTURE = 100
        private const val REQ_VIDEO = 101
    }
}
