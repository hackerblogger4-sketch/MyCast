package uz.mycast

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import java.io.ByteArrayOutputStream
import java.net.ServerSocket
import java.net.Socket
import kotlin.concurrent.thread

class CastService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var server: ServerSocket? = null
    private var bgThread: HandlerThread? = null

    @Volatile private var frame: ByteArray? = null
    @Volatile private var running = false
    private var lastTs = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action != ACTION_START) return START_NOT_STICKY

        startAsForeground()
        val code = intent.getIntExtra("code", 0)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        bgThread = HandlerThread("capture").also { it.start() }
        val handler = Handler(bgThread!!.looper)

        projection = mpm.getMediaProjection(code, data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, handler)
        }

        val m = resources.displayMetrics
        val scale = 720f / m.widthPixels.coerceAtLeast(1)
        val w = (m.widthPixels * scale).toInt().coerceAtLeast(2) and 1.inv()
        val h = (m.heightPixels * scale).toInt().coerceAtLeast(2) and 1.inv()

        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = System.currentTimeMillis()
                if (now - lastTs < 100) return@setOnImageAvailableListener // ~10 fps
                lastTs = now
                val p = img.planes[0]
                val rowPadding = p.rowStride - p.pixelStride * w
                val bmp = Bitmap.createBitmap(w + rowPadding / p.pixelStride, h, Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(p.buffer)
                val out = ByteArrayOutputStream()
                Bitmap.createBitmap(bmp, 0, 0, w, h).compress(Bitmap.CompressFormat.JPEG, 60, out)
                frame = out.toByteArray()
                bmp.recycle()
            } finally {
                img.close()
            }
        }, handler)

        display = projection!!.createVirtualDisplay(
            "MyCast", w, h, m.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        startServer()
        return START_NOT_STICKY
    }

    private fun startServer() {
        if (running) return
        running = true
        thread(name = "http") {
            try {
                server = ServerSocket(PORT)
                while (running) {
                    val s = server!!.accept()
                    thread { handleClient(s) }
                }
            } catch (_: Exception) { }
        }
    }

    private fun handleClient(s: Socket) {
        try {
            s.use {
                val line = it.getInputStream().bufferedReader().readLine() ?: return
                val out = it.getOutputStream()
                if (line.contains("/stream")) {
                    out.write(("HTTP/1.1 200 OK\r\nContent-Type: multipart/x-mixed-replace; boundary=frame\r\n" +
                        "Cache-Control: no-cache\r\nConnection: close\r\n\r\n").toByteArray())
                    while (running) {
                        val f = frame
                        if (f != null) {
                            out.write(("--frame\r\nContent-Type: image/jpeg\r\nContent-Length: ${f.size}\r\n\r\n").toByteArray())
                            out.write(f)
                            out.write("\r\n".toByteArray())
                            out.flush()
                        }
                        Thread.sleep(100)
                    }
                } else {
                    val html = "<html><body style='margin:0;background:#000'>" +
                        "<img src='/stream' style='width:100%;height:100vh;object-fit:contain'></body></html>"
                    out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html\r\nContent-Length: ${html.length}\r\n\r\n$html").toByteArray())
                    out.flush()
                }
            }
        } catch (_: Exception) { }
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("cast", "MyCast", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "cast")
            .setContentTitle("MyCast")
            .setContentText("Ekran yuborilmoqda")
            .setSmallIcon(android.R.drawable.ic_menu_share)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    override fun onDestroy() {
        running = false
        try { server?.close() } catch (_: Exception) { }
        display?.release()
        reader?.close()
        projection?.stop()
        bgThread?.quitSafely()
        super.onDestroy()
    }

    companion object {
        const val PORT = 8080
        const val ACTION_START = "uz.mycast.START"
        const val ACTION_STOP = "uz.mycast.STOP"
    }
}
