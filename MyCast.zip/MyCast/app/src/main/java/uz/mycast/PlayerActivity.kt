package uz.mycast

import android.app.Activity
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.MediaController
import android.widget.Toast
import android.widget.VideoView

class PlayerActivity : Activity() {
    private lateinit var video: VideoView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val url = intent.getStringExtra("url") ?: ""

        video = VideoView(this)
        val mc = MediaController(this)
        mc.setAnchorView(video)
        video.setMediaController(mc)

        val box = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(video, FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT,
                Gravity.CENTER))
        }
        setContentView(box)

        video.setOnPreparedListener { it.start() }
        video.setOnErrorListener { _, _, _ ->
            Toast.makeText(this,
                "Ijro etilmadi. VLC > Network stream ichida oching:\n$url",
                Toast.LENGTH_LONG).show()
            true
        }
        video.setVideoURI(Uri.parse(url))
    }

    override fun onDestroy() {
        video.stopPlayback()
        super.onDestroy()
    }
}
