# MyCast

Telefondagi kino yoki ekranni Wi-Fi orqali planshetga uzatuvchi oddiy Android ilovasi.
Rasmiy Google Cast emas: bu shaxsiy, oddiy HTTP asosidagi yechim.

## Rejimlar
- **Kino (ovoz bilan):** telefon tanlangan video faylni HTTP orqali beradi (port 8081), planshet ilova ichida ijro etadi.
- **Ekran (ovozsiz):** telefon ekranini MJPEG oqim qiladi (port 8080), planshet ko'rsatadi.

## Ishlatish
1. Ikkala qurilmaga APK o'rnating, bir xil Wi-Fi'ga ulang (yoki telefondan hotspot yoqing).
2. Telefonda **Kino yuborish** → videoni tanlang → ilova telefon IP'sini ko'rsatadi.
3. Planshetda IP'ni kiriting → **Kinoni ko'rish**.

Video ilovada ochilmasa, planshetda VLC → Network stream ga `http://<IP>:8081/video` ni kiriting.

## Telegram'dan to'g'ridan-to'g'ri
Telegram'da videoni oching (yoki xabarni uzoq bosing) → **Ulashish (Share) → MyCast**. Video darrov uzatishga tayyor bo'ladi.

## APK olish
Repo'ga push qiling → GitHub **Actions → Build APK** → Artifacts → `MyCast-debug-apk`.

## Cheklovlar
- Oqim shifrlanmagan va parolsiz: faqat ishonchli tarmoqda ishlating.
- Ichki ijrochi (VideoView) barcha formatni (AVI va h.k.) ochmasligi mumkin, bunda VLC ishlating.
- Ekran rejimida ovoz yo'q, kechikish 0.5-1 s.
